Pet QA intro final WebP assets
qa_bg_intro_final.webp: background WebP
qa_fg_intro_final.webp: foreground WebP with real alpha, checkerboard removed
{
  "foreground_size": [
    941,
    1672
  ],
  "alpha_min": 0,
  "alpha_max": 255,
  "transparent_pixels_ratio": 0.8076063080607518,
  "opaque_pixels_ratio": 0.1844215407613808,
  "has_real_alpha": true
}